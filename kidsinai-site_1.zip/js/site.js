/* Kids IN AI site runtime.
 * Each page ships two layouts in <template> tags: the desktop board (1440 px wide) and the phone board (390 px wide).
 * This file picks the one that fits the screen, scales it to the window width, fills its {{ holes }} from the page's
 * logic class, wires clicks and refs, and re-renders whenever the logic calls setState().
 */
(function () {
  'use strict';

  class DCLogic {
    constructor(props) { this.props = props || {}; this.state = {}; this._queued = false; this._render = null; }
    setState(patch) {
      if (typeof patch === 'function') { patch = patch(this.state || {}); }
      this.state = Object.assign({}, this.state || {}, patch || {});
      if (this._queued || !this._render) { return; }
      this._queued = true;
      requestAnimationFrame(() => { this._queued = false; this._render(); });
    }
  }
  window.DCLogic = DCLogic;

  const HOLE = /\{\{\s*([\w$.]+)\s*\}\}/g;
  const HAS_HOLE = /\{\{\s*[\w$.]+\s*\}\}/;
  const BREAK = 1000;                 // narrower than this: phone layout
  const DESK_W = 1440, PHONE_W = 390, PHONE_MAX_ZOOM = 2.2;   // tablets in portrait fill the width

  function lookup(vals, path) {
    if (path === 'true') { return true; }
    if (path === 'false') { return false; }
    let v = vals;
    for (const k of path.split('.')) { if (v == null) { return undefined; } v = v[k]; }
    return v;
  }
  function text(v) { return (v == null || v === false) ? '' : String(v); }

  function split(src) {               // "a {{ x }} b" -> ['a ', {path: 'x'}, ' b']
    const parts = [];
    let last = 0, m;
    HOLE.lastIndex = 0;
    while ((m = HOLE.exec(src))) {
      if (m.index > last) { parts.push(src.slice(last, m.index)); }
      parts.push({ path: m[1] });
      last = m.index + m[0].length;
    }
    if (last < src.length) { parts.push(src.slice(last)); }
    return parts;
  }
  function join(parts, vals) { return parts.map((p) => (typeof p === 'string' ? p : text(lookup(vals, p.path)))).join(''); }

  function mount(host, tpl, Logic, props) {
    const frag = tpl.content.cloneNode(true);
    const logic = new Logic(props);
    logic.state = logic.state || {};
    const binds = [], refs = [], walker = document.createTreeWalker(frag, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    let vals = {};

    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if (n.nodeType === 3) {
        if (HAS_HOLE.test(n.data)) { binds.push({ kind: 'text', node: n, parts: split(n.data), last: null }); }
        continue;
      }
      const el = n;
      for (const a of Array.from(el.attributes)) {
        const name = a.name, value = a.value;
        if (name === 'hint-placeholder-val') { el.removeAttribute(name); continue; }
        if (!HAS_HOLE.test(value)) { continue; }
        if (name === 'ref') {
          el.removeAttribute(name);
          refs.push({ el: el, path: split(value).find((p) => typeof p !== 'string').path });
        } else if (/^on[a-z]+$/.test(name)) {
          el.removeAttribute(name);           // never let the browser compile "{{ x }}" as script
          const path = split(value).find((p) => typeof p !== 'string').path;
          el.addEventListener(name.slice(2), (e) => { const fn = lookup(vals, path); if (typeof fn === 'function') { fn(e); } });
        } else if (el.localName === 'sc-if' && name === 'value') {
          el.removeAttribute(name);
          binds.push({ kind: 'if', el: el, path: split(value).find((p) => typeof p !== 'string').path, last: null });
        } else {
          binds.push({ kind: 'attr', el: el, name: name, parts: split(value), last: null });
        }
      }
    }

    function render() {
      vals = logic.renderVals() || {};
      for (const b of binds) {
        if (b.kind === 'text') {
          const v = join(b.parts, vals);
          if (v !== b.last) { b.node.data = v; b.last = v; }
        } else if (b.kind === 'attr') {
          const v = join(b.parts, vals);
          if (v !== b.last) { b.el.setAttribute(b.name, v); b.last = v; }
        } else {
          const on = !!lookup(vals, b.path);
          if (on !== b.last) { b.el.style.display = on ? 'contents' : 'none'; b.last = on; }
        }
      }
    }
    logic._render = render;
    render();
    host.appendChild(frag);
    for (const r of refs) { const fn = lookup(vals, r.path); if (typeof fn === 'function') { fn(r.el); } }
    if (typeof logic.componentDidMount === 'function') { logic.componentDidMount(); }
    window.addEventListener('pagehide', () => { if (typeof logic.componentWillUnmount === 'function') { logic.componentWillUnmount(); } });
    return host.lastElementChild;
  }

  // small message bar at the bottom of the screen (outside the scaled page, so it never moves the layout)
  function toast(msg) {
    let t = document.getElementById('kiai-toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'kiai-toast';
      t.setAttribute('role', 'status');
      t.style.cssText = 'position:fixed;left:50%;bottom:20px;transform:translateX(-50%);z-index:9999;width:max-content;max-width:min(92vw,560px);' +
        'box-sizing:border-box;padding:14px 18px;border-radius:16px;background:#0B2545;color:#FFFFFF;border:2.5px solid #FFD23F;' +
        'box-shadow:5px 5px 0 #FF5FA2;font:600 14px/1.5 "JetBrains Mono",monospace;text-align:center;';
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(t._h);
    t._h = setTimeout(() => { t.style.display = 'none'; }, 9000);
  }

  // forms: the Tech Day and contact forms open an email to Kids IN AI with everything filled in
  function wireForms(root) {
    root.querySelectorAll('[data-send]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const box = btn.parentElement;
        const fields = Array.from(box.querySelectorAll('input, textarea'));
        let ok = true;
        const lines = [];
        let who = '', school = '';
        fields.forEach((f) => {
          const label = box.querySelector('label[for="' + f.id + '"]');
          const name = label ? label.textContent.replace(/\*\s*$/, '').trim() : f.id;
          const required = label ? /\*\s*$/.test(label.textContent) : false;
          const v = f.value.trim();
          const bad = (required && !v) || (f.type === 'email' && v && !/^\S+@\S+\.\S+$/.test(v));
          f.style.outline = bad ? '3px solid #FF5FA2' : '';
          if (bad) { ok = false; }
          if (v) { lines.push(name + ': ' + v); }
          if (!who && /name/i.test(name)) { who = v; }
          if (!school && /school/i.test(name)) { school = v; }
        });
        if (!ok) { toast('Please fill in the boxes marked * (and check the email address).'); return; }
        const subject = (btn.getAttribute('data-send') === 'tech-day' ? 'Tech Day request' : 'Website message') + (who ? ' from ' + who : '') + (school ? ' (' + school + ')' : '');
        toast('\u2709 Your email app is opening with your message. No email app? Write to info@kidsinai.org');
        window.KIAI.openMail('mailto:info@kidsinai.org?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(lines.join('\n')));
      });
    });
  }

  function boot(layouts) {
    const host = document.getElementById('app');
    const mode = () => (document.documentElement.clientWidth < BREAK ? 'mob' : 'desk');
    const current = mode();
    const L = layouts[current];
    const root = mount(host, document.getElementById(L.template), L.logic, { mediaLabels: false });
    root.style.height = 'auto';             // let the page grow with its real content
    const fit = () => {
      const w = document.documentElement.clientWidth;
      if (current === 'desk') { root.style.zoom = String(w / DESK_W); }
      else { root.style.zoom = String(Math.min(w / PHONE_W, PHONE_MAX_ZOOM)); root.style.margin = '0 auto'; }
    };
    fit();
    wireForms(root);
    let t = null;
    window.addEventListener('resize', () => {
      clearTimeout(t);
      t = setTimeout(() => { if (mode() !== current) { window.location.reload(); } else { fit(); } }, 150);
    });
  }

  window.KIAI = { boot: boot, openMail: function (url) { window.location.href = url; } };
})();
